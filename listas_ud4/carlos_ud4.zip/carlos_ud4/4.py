def filas_columnas_matriz(matriz: list) -> list:
    num_filas_columnas = []
    num_filas_columnas.append(len(matriz))
    num_filas_columnas.append(len(matriz[0]))
    return num_filas_columnas