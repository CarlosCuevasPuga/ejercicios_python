from dataclasses import dataclass

@dataclass
class Planeta:
    nombre: str
    rocoso: bool
    num_lunas: int